**********
Change log
**********

What is new with Pywikibot |release|? What are the main changes of older version?

.. include:: ../ROADMAP.rst

.. include:: ../HISTORY.rst
