***********************************
:mod:`plural` --- i18n Plural rules
***********************************

.. automodule:: plural
   :synopsis: Module containing plural rules of various languages
