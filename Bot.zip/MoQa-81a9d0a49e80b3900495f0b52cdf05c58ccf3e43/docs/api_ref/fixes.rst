*****************************************************
:mod:`fixes` --- standard fixes for replace.py script
*****************************************************

.. automodule:: fixes
   :synopsis: File containing all standard fixes
