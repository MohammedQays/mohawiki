*************************************
:mod:`backports` --- Python Backports
*************************************

.. automodule:: backports
   :synopsis: This module contains backports to support older Python versions
