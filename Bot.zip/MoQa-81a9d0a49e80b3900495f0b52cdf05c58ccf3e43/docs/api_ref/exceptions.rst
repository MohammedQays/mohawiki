****************************************************
:mod:`exceptions` --- Exceptions and Warning Classes
****************************************************

.. automodule:: exceptions
   :synopsis: Pywikibot exceptions and warning classes
