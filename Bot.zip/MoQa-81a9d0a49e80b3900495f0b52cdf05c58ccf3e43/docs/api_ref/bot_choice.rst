*********************************************
:mod:`bot\_choice` --- UI Options and Choices
*********************************************

.. automodule:: bot_choice
   :synopsis: Options and Choices for :func:`pywikibot.input_choice`
