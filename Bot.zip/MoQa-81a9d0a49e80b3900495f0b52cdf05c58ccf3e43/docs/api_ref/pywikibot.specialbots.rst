********************************************
:mod:`specialbots` --- Special Reusable Bots
********************************************

.. automodule:: specialbots
   :synopsis: Module containing special bots reusable by scripts
