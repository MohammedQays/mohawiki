*******************************************************
:mod:`tools.chars` --- Character Based Helper Functions
*******************************************************

.. automodule:: tools.chars
   :synopsis: Character based helper functions (not wiki-dependent)
