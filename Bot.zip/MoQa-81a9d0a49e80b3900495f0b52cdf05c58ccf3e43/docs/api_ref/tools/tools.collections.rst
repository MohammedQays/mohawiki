************************************************
:mod:`tools.collections` --- Container datatypes
************************************************

.. automodule:: tools.collections
   :synopsis: Collections datatypes
