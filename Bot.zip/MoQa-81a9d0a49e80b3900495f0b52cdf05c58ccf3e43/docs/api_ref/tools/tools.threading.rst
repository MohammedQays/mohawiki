***********************************************
:mod:`tools.threading` --- Thread-based Classes
***********************************************
.. automodule:: tools.threading
   :synopsis: Threading classes
