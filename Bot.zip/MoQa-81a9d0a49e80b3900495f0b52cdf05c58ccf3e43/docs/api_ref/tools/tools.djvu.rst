****************************************
:mod:`tools.djvu` --- DJVU files wrapper
****************************************

.. automodule:: tools.djvu
   :synopsis: Wrapper around djvulibre to access djvu files properties and content
