***********************************************
:mod:`flow` --- Structured Discussions Entities
***********************************************

.. automodule:: flow
   :synopsis: Objects representing Structured Discussions entities, like boards, topics, and posts
