******************************************
:mod:`date` --- Date Classes and Functions
******************************************

.. automodule:: date
   :synopsis: Date data and manipulation module
