************************
:mod:`logentries` module
************************

.. automodule:: logentries
   :synopsis: Objects representing MediaWiki log entries
