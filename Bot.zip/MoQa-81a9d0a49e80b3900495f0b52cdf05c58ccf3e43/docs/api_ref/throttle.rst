**************************************
:mod:`throttle` --- Slow Down Wiki I/O
**************************************

.. automodule:: throttle
   :synopsis: Mechanics to slow down wiki read and/or write rate
