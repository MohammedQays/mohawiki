*************************
Framework utility scripts
*************************

.. automodule:: pywikibot.scripts
   :no-members:
   :noindex:

pwb wrapper script
==================

.. automodule:: pywikibot.scripts.wrapper
   :no-members:
   :noindex:

generate\_family\_file script
=============================

.. automodule:: pywikibot.scripts.generate_family_file
   :no-members:
   :noindex:

generate\_user\_files script
============================

.. automodule:: pywikibot.scripts.generate_user_files
   :no-members:
   :noindex:

login script
============

.. automodule:: pywikibot.scripts.login
   :no-members:
   :noindex:

shell script
============

.. automodule:: pywikibot.scripts.shell
   :no-members:
   :noindex:

version script
==============

.. automodule:: pywikibot.scripts.version
   :no-members:
   :noindex:
