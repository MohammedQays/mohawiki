###############
Tests reference
###############

.. include:: ../../tests/README.rst


**************
Test utilities
**************

.. toctree::
   :titlesonly:

   aspects
   basepage
   utils
