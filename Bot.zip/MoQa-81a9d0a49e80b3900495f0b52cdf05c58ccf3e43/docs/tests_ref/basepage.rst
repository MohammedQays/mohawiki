*********************
tests.basepage module
*********************

.. automodule:: tests.basepage
    :members:
    :undoc-members:
    :show-inheritance:
