*****************
Other bot scripts
*****************

welcome script
==============

.. automodule:: scripts.welcome
   :no-members:
   :noindex:
