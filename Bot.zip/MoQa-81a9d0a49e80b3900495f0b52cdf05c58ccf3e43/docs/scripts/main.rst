****************
Main bot scripts
****************

add\_text script
================

.. automodule:: scripts.add_text
   :no-members:
   :noindex:

category script
===============

.. automodule:: scripts.category
   :no-members:
   :noindex:

replace script
==============

.. automodule:: scripts.replace
   :no-members:
   :noindex:

solve\_disambiguation script
============================

.. automodule:: scripts.solve_disambiguation
   :no-members:
   :noindex:

upload script
=============

.. automodule:: scripts.upload
   :no-members:
   :noindex:

weblinkchecker script
=====================

.. automodule:: scripts.weblinkchecker
   :no-members:
   :noindex:
