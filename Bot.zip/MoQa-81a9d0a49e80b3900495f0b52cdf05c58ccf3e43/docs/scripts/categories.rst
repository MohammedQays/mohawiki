******************
Categories scripts
******************

category\_redirect script
=========================

.. automodule:: scripts.category_redirect
   :no-members:
   :noindex:

category\_graph script
======================

.. automodule:: scripts.category_graph
   :no-members:
   :noindex:

commonscat script
=================

.. automodule:: scripts.commonscat
   :no-members:
   :noindex:
