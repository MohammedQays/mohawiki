**********************
Administrative scripts
**********************

blockpageschecker script
========================

.. automodule:: scripts.blockpageschecker
   :no-members:
   :noindex:

delete script
=============

.. automodule:: scripts.delete
   :no-members:
   :noindex:

patrol script
=============

.. automodule:: scripts.patrol
   :no-members:
   :noindex:

protect script
==============

.. automodule:: scripts.protect
   :no-members:
   :noindex:

revertbot script
================

.. automodule:: scripts.revertbot
   :no-members:
   :noindex:

speedy\_delete script
=====================

.. automodule:: scripts.speedy_delete
   :no-members:
   :noindex:
