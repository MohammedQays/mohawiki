:orphan:

************
Installation
************

Moved to :doc:`introduction`.
