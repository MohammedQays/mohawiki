*******
Credits
*******

.. include:: ../AUTHORS.rst
