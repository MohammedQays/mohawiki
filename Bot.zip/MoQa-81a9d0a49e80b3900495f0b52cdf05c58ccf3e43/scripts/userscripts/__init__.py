"""THIS DIRECTORY IS TO HOLD USER-DEFINED BOT SCRIPTS."""

from __future__ import annotations
